#!/usr/bin/env python3
from pathlib import Path
import json, sys, hashlib
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'data'/'reading_bundle_01_105.json'
o=json.loads(p.read_text(encoding='utf-8'))
expected={
 'reading_tests':33,'reading_passages':105,'assessment_questions':1406,
 'assessment_answers':1406,'assessment_evidence':1406,
 'lexemes':2589,'lexical_senses':2591,'lexical_occurrences':3930,
}
errors=[]
for k,n in expected.items():
 a=len(o.get(k,[]))
 print(f'{k}: {a} / expected {n}')
 if a!=n: errors.append(f'{k}: {a} != {n}')
# referential integrity on package refs
refs={
 'content_items':{x['ref'] for x in o['content_items']},
 'segments':{x['ref'] for x in o['content_segments']},
 'lexemes':{x['id'] for x in o['lexemes']},
 'senses':{x['id'] for x in o['lexical_senses']},
 'questions':{x['ref'] for x in o['assessment_questions']},
}
for x in o['lexical_occurrences']:
 if x['content_item_ref'] not in refs['content_items']: errors.append('bad occurrence content_item_ref')
 if x['segment_ref'] not in refs['segments']: errors.append('bad occurrence segment_ref')
 if x['lexeme_ref'] not in refs['lexemes']: errors.append('bad occurrence lexeme_ref')
 if x.get('sense_ref') and x['sense_ref'] not in refs['senses']: errors.append('bad occurrence sense_ref')
for x in o['assessment_answers']:
 if x['question_ref'] not in refs['questions']: errors.append('bad answer question_ref')
function_targets=sum(1 for x in o['lexical_occurrences'] if x.get('is_target_vocabulary') and next((l for l in o['lexemes'] if l['id']==x['lexeme_ref']),{}).get('is_function_word'))
print('function-word target occurrences:', function_targets)
if function_targets: errors.append('function words marked as target vocabulary')
print('source validation:',o.get('validation',{}).get('status'))
if errors:
 print('FAILED:', errors[:20]); sys.exit(1)
print('PACKAGE VALIDATION: PASSED')
