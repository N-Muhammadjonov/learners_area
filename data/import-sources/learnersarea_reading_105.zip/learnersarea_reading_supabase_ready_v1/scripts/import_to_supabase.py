#!/usr/bin/env python3
"""Idempotent Learners Area Reading 01-105 importer for Supabase/PostgreSQL.

Usage:
  pip install -r requirements.txt
  export DATABASE_URL='postgresql://...'
  python scripts/import_to_supabase.py

Use a Supabase database connection string with privileges to create/write these tables.
Never commit DATABASE_URL to GitHub.
"""
from pathlib import Path
import argparse, json, os, sys
import psycopg
from psycopg.types.json import Jsonb

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = ROOT / 'data' / 'reading_bundle_01_105.json'

TABLES = [
 ('content_sources','content_sources', {
  'ref':'id','name':'name','provider':'provider','source_kind':'source_kind','base_url':'base_url','metadata':'metadata'}),
 ('content_collections','content_collections', {
  'ref':'id','source_ref':'source_id','external_id':'external_id','title':'title','collection_type':'collection_type','language':'language','metadata':'metadata'}),
 ('reading_tests','reading_tests', {
  'ref':'id','collection_ref':'collection_id','external_test_no':'external_test_no','title':'title','position':'position','metadata':'metadata'}),
 ('source_documents','source_documents', {
  'ref':'id','source_ref':'source_id','external_id':'external_id','source_url':'source_url','mime_type':'mime_type','raw_sha256':'raw_sha256','parser_version':'parser_version','metadata':'metadata'}),
 ('content_items','content_items', {
  'ref':'id','collection_ref':'collection_id','source_document_ref':'source_document_id','external_id':'external_id','content_type':'content_type','title':'title','subtitle':'subtitle','language':'language','sequence_no':'sequence_no','source_url':'source_url','source_slug':'source_slug','source_checksum':'source_checksum','extraction_status':'extraction_status','metadata':'metadata'}),
 ('content_segments','content_segments', {
  'ref':'id','content_item_ref':'content_item_id','parent_segment_ref':'parent_segment_id','segment_type':'segment_type','segment_key':'segment_key','position':'position','start_ms':'start_ms','end_ms':'end_ms','text':'text','text_sha256':'text_sha256','source_locator':'source_locator','metadata':'metadata'}),
 ('reading_passages','reading_passages', {
  'ref':'id','content_item_ref':'content_item_id','test_ref':'test_id','passage_no':'passage_no','instructions':'instructions','source_question_count':'source_question_count','source_word_count':'source_word_count','topic_code':'topic_code','metadata':'metadata'}),
 ('reading_paragraphs','reading_paragraphs', {
  'ref':'id','passage_ref':'passage_id','segment_ref':'segment_id','paragraph_label':'paragraph_label','position':'position','is_footnote':'is_footnote'}),
 ('assessment_groups','assessment_groups', {
  'ref':'id','content_item_ref':'content_item_id','position':'position','type_code':'type_code','display_title':'display_title','instructions_text':'instructions_text','instructions_source_html':'instructions_source_html','stimulus_text':'stimulus_text','stimulus_source_html':'stimulus_source_html','stimulus_content':'stimulus_content','from_question_no':'from_question_no','to_question_no':'to_question_no','config':'config','source_locator':'source_locator'}),
 ('assessment_questions','assessment_questions', {
  'ref':'id','content_item_ref':'content_item_id','group_ref':'group_id','question_no':'question_no','source_key':'source_key','prompt_text':'prompt_text','prompt_source_html':'prompt_source_html','prompt_content':'prompt_content','answer_constraint':'answer_constraint','source_locator':'source_locator'}),
 ('assessment_question_options','assessment_question_options', {
  'ref':'id','question_ref':'question_id','option_key':'option_key','option_text':'option_text','position':'position','metadata':'metadata'}),
 ('assessment_answers','assessment_answers', {
  'ref':'id','question_ref':'question_id','canonical_answer':'canonical_answer','answer_kind':'answer_kind','provenance':'provenance','source_locator':'source_locator','metadata':'metadata'}),
 ('assessment_answer_variants','assessment_answer_variants', {
  'ref':'id','answer_ref':'answer_id','accepted_answer':'accepted_answer','normalized_answer':'normalized_answer','provenance':'provenance'}),
 ('assessment_evidence','assessment_evidence', {
  'ref':'id','question_ref':'question_id','segment_ref':'segment_id','evidence_type':'evidence_type','evidence_text':'evidence_text','start_char':'start_char','end_char':'end_char','start_ms':'start_ms','end_ms':'end_ms','marker_key':'marker_key','explanation':'explanation','provenance':'provenance','confidence':'confidence','verification_status':'verification_status','source_locator':'source_locator'}),
 ('lexemes','lexemes', {
  'id':'id','language':'language','lemma':'lemma','normalized_lemma':'normalized_lemma','part_of_speech':'part_of_speech','lexical_type':'lexical_type','is_function_word':'is_function_word','metadata':'metadata'}),
 ('lexical_forms','lexical_forms', {
  'ref':'id','lexeme_ref':'lexeme_id','surface_form':'surface_form','normalized_form':'normalized_form','form_type':'form_type','metadata':'metadata'}),
 ('lexical_senses','lexical_senses', {
  'id':'id','lexeme_id':'lexeme_id','sense_key':'sense_key','definition_en':'definition_en','translation_uz':'translation_uz','provenance':'provenance','confidence':'confidence','verification_status':'verification_status','usage_notes':'usage_notes','metadata':'metadata'}),
 ('lexical_occurrences','lexical_occurrences', {
  'ref':'id','content_item_ref':'content_item_id','segment_ref':'segment_id','lexeme_ref':'lexeme_id','sense_ref':'sense_id','surface_form':'surface_form','normalized_surface':'normalized_surface','start_char':'start_char','end_char':'end_char','start_ms':'start_ms','end_ms':'end_ms','sentence_text':'sentence_text','context_text':'context_text','occurrence_type':'occurrence_type','is_target_vocabulary':'is_target_vocabulary','selection_reason':'selection_reason','provenance':'provenance','extraction_method':'extraction_method','extractor_version':'extractor_version','confidence':'confidence','verification_status':'verification_status','metadata':'metadata'}),
]

JSON_COLS = {
 'metadata','source_locator','stimulus_content','config','prompt_content','answer_constraint',
 'canonical_answer','translation_uz'
}

EXPECTED = {
 'reading_passages':105,
 'assessment_questions':1406,
 'assessment_answers':1406,
 'assessment_evidence':1406,
 'lexemes':2589,
 'lexical_senses':2591,
 'lexical_occurrences':3930,
}

def adapt_value(column, value):
    if column in JSON_COLS:
        return Jsonb(value if value is not None else ({} if column != 'translation_uz' else []))
    return value

def upsert_rows(cur, table, rows, mapping, chunk=500):
    if not rows:
        return 0
    cols=list(mapping.values())
    src=list(mapping.keys())
    placeholders=', '.join(['%s']*len(cols))
    updates=', '.join(f'{c}=excluded.{c}' for c in cols if c != 'id')
    sql=f"insert into public.{table} ({', '.join(cols)}) values ({placeholders}) on conflict (id) do update set {updates}"
    count=0
    for start in range(0,len(rows),chunk):
        vals=[]
        for row in rows[start:start+chunk]:
            vals.append(tuple(adapt_value(mapping[s], row.get(s)) for s in src))
        cur.executemany(sql, vals)
        count += len(vals)
        print(f'  {table}: {count}/{len(rows)}')
    return count

def validate_bundle(bundle):
    errors=[]
    for key,n in EXPECTED.items():
        if len(bundle.get(key,[])) != n:
            errors.append(f'{key}: expected {n}, got {len(bundle.get(key,[]))}')
    if bundle.get('validation',{}).get('status') != 'PASSED':
        errors.append('source bundle validation status is not PASSED')
    return errors

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data', type=Path, default=DEFAULT_DATA)
    ap.add_argument('--database-url', default=os.getenv('DATABASE_URL'))
    ap.add_argument('--dry-run', action='store_true')
    args=ap.parse_args()
    bundle=json.loads(args.data.read_text(encoding='utf-8'))
    errors=validate_bundle(bundle)
    if errors:
        print('BUNDLE VALIDATION FAILED:')
        for e in errors: print(' -',e)
        sys.exit(2)
    print('Bundle validation: PASSED')
    print('Passages:',len(bundle['reading_passages']),'Questions:',len(bundle['assessment_questions']),'Lexemes:',len(bundle['lexemes']))
    if args.dry_run:
        print('Dry run complete; no database changes made.')
        return
    if not args.database_url:
        sys.exit('DATABASE_URL is missing. Copy .env.example and use your Supabase database connection string.')
    with psycopg.connect(args.database_url) as conn:
        with conn.cursor() as cur:
            for bundle_key,table,mapping in TABLES:
                print(f'Importing {table}...')
                upsert_rows(cur,table,bundle.get(bundle_key,[]),mapping)
        conn.commit()
        print('Import committed.')
        with conn.cursor() as cur:
            for table,expected in EXPECTED.items():
                cur.execute(f'select count(*) from public.{table}')
                actual=cur.fetchone()[0]
                print(f'{table}: {actual} rows (package baseline {expected})')
    print('DONE')

if __name__ == '__main__': main()
