# Learners Area Reading — Supabase Ready v1

This package imports the finalized Reading 01–105 dataset into Supabase/PostgreSQL.

## Package baseline
- 105 reading passages
- 33 source-grouped reading tests
- 1,406 questions
- 1,406 canonical answers
- 1,406 evidence records (1,233 source markers + 173 explicit missing-source markers)
- 2,589 canonical lexemes
- 2,591 contextual senses
- 3,930 lexical occurrences

Important: passages 100–105 are standalone custom reading items in the current canonical dataset. They are NOT silently fabricated into Tests 34–35. You can later curate their grouping explicitly.

## What goes to Supabase
Structured/queryable data: passages, paragraphs, question groups, questions, options, answer key, evidence, lexemes, senses, exact contextual occurrences, and student SRS tables.

Large media files (future Listening audio, images, PDFs, user uploads) belong in Cloudflare R2; store only their keys/URLs in Supabase.

Source code belongs in GitHub. Secrets never belong in GitHub.

## Import order
1. In Supabase SQL Editor, run `sql/001_schema.sql`.
2. Run `sql/001b_schema_patch.sql`.
3. On your Mac/Cursor terminal:
   - `python3 -m venv .venv`
   - `source .venv/bin/activate`
   - `pip install -r requirements.txt`
   - set `DATABASE_URL` to the Supabase Postgres connection string.
   - `python scripts/validate_package.py`
   - `python scripts/import_to_supabase.py --dry-run`
   - `python scripts/import_to_supabase.py`
4. Back in SQL Editor, run `sql/002_frontend_views.sql`.
5. Run `sql/003_security_and_rpc.sql`.
6. Run `sql/004_post_import_indexes.sql`.
7. Run `sql/005_validate_after_import.sql` and confirm expected counts.

## Frontend/Arena integration
Use these safe views:
- `v_reading_library_cards` — cards like Test / Passage / topic / question type / counts.
- `v_reading_passage_segments` — passage paragraphs.
- `v_reading_questions_public` — questions/options with NO answer key.
- `v_reading_passage_vocabulary` — exact clickable vocabulary ranges + contextual sense + Uzbek translation.
- `v_lexicon` — global Dictionary/Vocabulary section.

To grade a reading, call RPC `grade_reading_answers(content_item_id, answers_json)` rather than exposing the answer tables.

For a word click popup, render the paragraph text and match the `start_char`/`end_char` ranges from `v_reading_passage_vocabulary`. The popup can show lemma, POS, lexical type, `translation_uz`, `definition_en`, and a speaker button. Pronunciation audio is a frontend feature (Web Speech API initially, or stored audio later); it is not embedded in this dataset yet.

## Security
- Public question views do not expose canonical answers.
- Answer/evidence/source-document tables are protected by RLS.
- Student SRS state is owner-only via `auth.uid()` policies.
- Import uses deterministic UUIDs and UPSERT, so rerunning the same package is idempotent.

## Branding/provenance
Learner-facing records use Learners Area branding. Internal provenance should remain truthful and separate from public presentation.
