-- Post-import indexes and QA conveniences
create index if not exists idx_reading_library_sequence on public.content_items(sequence_no) where content_type='reading_passage';
create index if not exists idx_reading_topic on public.reading_passages(topic_code);
create index if not exists idx_occurrence_click_range on public.lexical_occurrences(segment_id, start_char, end_char) where is_target_vocabulary=true;
create index if not exists idx_senses_translation_uz_gin on public.lexical_senses using gin (translation_uz);

analyze public.content_items;
analyze public.content_segments;
analyze public.assessment_questions;
analyze public.lexical_occurrences;
analyze public.lexemes;
analyze public.lexical_senses;
