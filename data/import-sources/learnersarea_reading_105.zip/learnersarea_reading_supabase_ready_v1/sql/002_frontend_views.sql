-- Learners Area frontend-safe views for Reading Library and contextual vocabulary

create or replace view public.v_reading_library_cards as
select
  ci.id as content_item_id,
  ci.sequence_no as library_id,
  rt.external_test_no as test_no,
  rp.passage_no,
  ci.title,
  ci.subtitle,
  rp.topic_code,
  rp.source_question_count as question_count,
  rp.source_word_count as word_count,
  coalesce(
    array_agg(distinct ag.type_code order by ag.type_code)
      filter (where ag.type_code is not null),
    '{}'::text[]
  ) as question_types,
  ci.extraction_status,
  ci.metadata
from public.content_items ci
join public.reading_passages rp on rp.content_item_id = ci.id
left join public.reading_tests rt on rt.id = rp.test_id
left join public.assessment_groups ag on ag.content_item_id = ci.id
where ci.content_type = 'reading_passage'
group by ci.id, ci.sequence_no, rt.external_test_no, rp.passage_no,
         ci.title, ci.subtitle, rp.topic_code, rp.source_question_count,
         rp.source_word_count, ci.extraction_status, ci.metadata;

create or replace view public.v_reading_passage_segments as
select
  ci.id as content_item_id,
  ci.sequence_no as library_id,
  rp.id as passage_id,
  cs.id as segment_id,
  rpseg.position,
  rpseg.paragraph_label,
  rpseg.is_footnote,
  cs.segment_type,
  cs.segment_key,
  cs.text
from public.content_items ci
join public.reading_passages rp on rp.content_item_id = ci.id
join public.reading_paragraphs rpseg on rpseg.passage_id = rp.id
join public.content_segments cs on cs.id = rpseg.segment_id
order by ci.sequence_no, rpseg.position;

create or replace view public.v_reading_questions_public as
select
  aq.id as question_id,
  aq.content_item_id,
  ag.id as group_id,
  ag.position as group_position,
  ag.type_code,
  ag.display_title,
  ag.instructions_text,
  ag.stimulus_text,
  ag.stimulus_content,
  aq.question_no,
  aq.source_key,
  aq.prompt_text,
  aq.prompt_content,
  aq.answer_constraint,
  coalesce(
    jsonb_agg(
      jsonb_build_object(
        'key', o.option_key,
        'text', o.option_text,
        'position', o.position,
        'metadata', o.metadata
      ) order by o.position
    ) filter (where o.id is not null),
    '[]'::jsonb
  ) as options
from public.assessment_questions aq
join public.assessment_groups ag on ag.id = aq.group_id
left join public.assessment_question_options o on o.question_id = aq.id
group by aq.id, aq.content_item_id, ag.id, ag.position, ag.type_code,
         ag.display_title, ag.instructions_text, ag.stimulus_text,
         ag.stimulus_content, aq.question_no, aq.source_key,
         aq.prompt_text, aq.prompt_content, aq.answer_constraint;

-- Exact contextual vocabulary. Frontend can render segment text normally,
-- then make only the occurrence ranges clickable using start_char/end_char.
create or replace view public.v_reading_passage_vocabulary as
select
  lo.id as occurrence_id,
  lo.content_item_id,
  lo.segment_id,
  ci.sequence_no as library_id,
  lo.surface_form,
  lo.start_char,
  lo.end_char,
  lo.sentence_text,
  lo.context_text,
  lo.occurrence_type,
  lo.confidence as occurrence_confidence,
  l.id as lexeme_id,
  l.lemma,
  l.part_of_speech,
  l.lexical_type,
  ls.id as sense_id,
  ls.sense_key,
  ls.definition_en,
  ls.translation_uz,
  ls.cefr,
  ls.register,
  ls.domain_tags,
  ls.usage_notes,
  ls.verification_status as sense_verification_status
from public.lexical_occurrences lo
join public.content_items ci on ci.id = lo.content_item_id
join public.lexemes l on l.id = lo.lexeme_id
left join public.lexical_senses ls on ls.id = lo.sense_id
where lo.is_target_vocabulary = true
  and l.is_function_word = false;

-- Lightweight lookup for the Vocabulary section; one canonical lexeme may have many senses.
create or replace view public.v_lexicon as
select
  l.id as lexeme_id,
  l.language,
  l.lemma,
  l.normalized_lemma,
  l.part_of_speech,
  l.lexical_type,
  l.metadata as lexeme_metadata,
  ls.id as sense_id,
  ls.sense_key,
  ls.definition_en,
  ls.translation_uz,
  ls.cefr,
  ls.register,
  ls.domain_tags,
  ls.usage_notes,
  ls.confidence,
  ls.verification_status
from public.lexemes l
join public.lexical_senses ls on ls.lexeme_id = l.id
where l.is_active = true and ls.is_active = true and l.is_function_word = false;
