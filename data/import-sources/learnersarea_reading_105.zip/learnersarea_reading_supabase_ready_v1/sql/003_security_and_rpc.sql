-- Learners Area RLS and grading RPC
-- Public learning content is readable by anon/authenticated users.
-- Canonical answers/evidence are NOT directly readable, to avoid exposing answer keys.
-- Student SRS tables already have owner-only policies in 001_schema.sql.

-- Enable RLS on learner-facing content tables.
alter table public.content_sources enable row level security;
alter table public.content_collections enable row level security;
alter table public.content_items enable row level security;
alter table public.content_segments enable row level security;
alter table public.reading_tests enable row level security;
alter table public.reading_passages enable row level security;
alter table public.reading_paragraphs enable row level security;
alter table public.assessment_groups enable row level security;
alter table public.assessment_questions enable row level security;
alter table public.assessment_question_options enable row level security;
alter table public.lexemes enable row level security;
alter table public.lexical_forms enable row level security;
alter table public.lexical_senses enable row level security;
alter table public.lexical_occurrences enable row level security;

-- Sensitive answer/evidence tables stay behind RLS without anon/authenticated SELECT policies.
alter table public.assessment_answers enable row level security;
alter table public.assessment_answer_variants enable row level security;
alter table public.assessment_evidence enable row level security;
alter table public.source_documents enable row level security;
alter table public.ingestion_runs enable row level security;

-- Idempotent public read policies.
do $$
declare t text;
begin
  foreach t in array array[
    'content_sources','content_collections','content_items','content_segments',
    'reading_tests','reading_passages','reading_paragraphs',
    'assessment_groups','assessment_questions','assessment_question_options',
    'lexemes','lexical_forms','lexical_senses','lexical_occurrences'
  ] loop
    execute format('drop policy if exists %I on public.%I', 'Learners Area read', t);
    execute format(
      'create policy %I on public.%I for select to anon, authenticated using (true)',
      'Learners Area read', t
    );
  end loop;
end $$;

-- Secure server-side grading: users send {"1":"answer", "2":"TRUE", ...}.
-- Exact normalization mirrors the source grading behavior at a basic level.
create or replace function public.grade_reading_answers(
  p_content_item_id uuid,
  p_answers jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r record;
  user_answer text;
  norm_user text;
  norm_correct text;
  is_correct boolean;
  total_count integer := 0;
  score_count integer := 0;
  details jsonb := '[]'::jsonb;
begin
  for r in
    select
      q.question_no,
      a.id as answer_id,
      a.canonical_answer,
      coalesce(
        (select jsonb_agg(v.normalized_answer)
           from public.assessment_answer_variants v
          where v.answer_id = a.id),
        '[]'::jsonb
      ) as variants
    from public.assessment_questions q
    join public.assessment_answers a on a.question_id = q.id
    where q.content_item_id = p_content_item_id
    order by q.question_no
  loop
    total_count := total_count + 1;
    user_answer := coalesce(p_answers ->> r.question_no::text, '');
    norm_user := lower(regexp_replace(trim(user_answer), '[.,!?;:''"]', '', 'g'));
    norm_user := regexp_replace(norm_user, '\s+', ' ', 'g');
    norm_correct := lower(regexp_replace(trim(r.canonical_answer #>> '{}'), '[.,!?;:''"]', '', 'g'));
    norm_correct := regexp_replace(norm_correct, '\s+', ' ', 'g');

    is_correct := (norm_user <> '' and norm_user = norm_correct)
      or exists (
        select 1
        from jsonb_array_elements_text(r.variants) x(v)
        where x.v = norm_user
      );

    if is_correct then score_count := score_count + 1; end if;

    details := details || jsonb_build_array(jsonb_build_object(
      'question_no', r.question_no,
      'correct', is_correct,
      'correct_answer', r.canonical_answer
    ));
  end loop;

  return jsonb_build_object(
    'score', score_count,
    'total', total_count,
    'percent', case when total_count = 0 then 0 else round(score_count * 100.0 / total_count) end,
    'details', details
  );
end;
$$;

revoke all on function public.grade_reading_answers(uuid,jsonb) from public;
grant execute on function public.grade_reading_answers(uuid,jsonb) to anon, authenticated;

-- Views contain no canonical answer key.
grant select on public.v_reading_library_cards to anon, authenticated;
grant select on public.v_reading_passage_segments to anon, authenticated;
grant select on public.v_reading_questions_public to anon, authenticated;
grant select on public.v_reading_passage_vocabulary to anon, authenticated;
grant select on public.v_lexicon to anon, authenticated;
