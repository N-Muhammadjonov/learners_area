-- Learners Area Universal Content + Assessment + Sense-Aware Lexicon
-- Frozen schema v1.1 for Reading now; reusable for Listening, TED/video, podcasts, lessons later.
-- Target: Supabase / PostgreSQL

create extension if not exists pgcrypto;

-- ============================================================
-- 1. SOURCES / COLLECTIONS / INGESTION
-- ============================================================
create table if not exists content_sources (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  provider text,
  source_kind text not null check (source_kind in ('reading','listening','video','podcast','lesson','mixed','other')),
  base_url text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(name, source_kind)
);

create table if not exists content_collections (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references content_sources(id) on delete cascade,
  external_id text,
  title text not null,
  collection_type text not null check (collection_type in ('reading_library','reading_test_set','listening_library','video_library','podcast_library','course','other')),
  language text not null default 'en',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(source_id, external_id)
);

create table if not exists ingestion_runs (
  id uuid primary key default gen_random_uuid(),
  collection_id uuid references content_collections(id) on delete cascade,
  run_key text not null unique,
  schema_version text not null,
  extractor_name text not null,
  extractor_version text not null,
  status text not null check (status in ('planned','running','parsed','validated','needs_review','failed','published')),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  stats jsonb not null default '{}'::jsonb,
  errors jsonb not null default '[]'::jsonb
);

create table if not exists source_documents (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references content_sources(id) on delete cascade,
  ingestion_run_id uuid references ingestion_runs(id) on delete set null,
  external_id text,
  source_url text,
  mime_type text,
  raw_storage_key text,
  raw_sha256 text,
  fetched_at timestamptz,
  parser_version text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check (raw_sha256 is null or raw_sha256 ~ '^[0-9a-fA-F]{64}$')
);
create index if not exists idx_source_documents_source on source_documents(source_id);
create index if not exists idx_source_documents_sha on source_documents(raw_sha256);

-- ============================================================
-- 2. UNIVERSAL CONTENT
-- ============================================================
create table if not exists content_items (
  id uuid primary key default gen_random_uuid(),
  collection_id uuid not null references content_collections(id) on delete cascade,
  source_document_id uuid references source_documents(id) on delete set null,
  external_id text,
  content_type text not null check (content_type in ('reading_passage','listening_part','video','podcast_episode','lesson','other')),
  title text not null,
  subtitle text,
  language text not null default 'en',
  sequence_no integer,
  source_url text,
  source_slug text,
  source_checksum text,
  extraction_status text not null default 'raw' check (extraction_status in ('raw','parsed','validated','needs_review','published','failed')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(collection_id, external_id)
);
create index if not exists idx_content_items_collection on content_items(collection_id, sequence_no);
create index if not exists idx_content_items_type on content_items(content_type);

-- Paragraphs for Reading and timestamped transcript/caption chunks for audio/video all live here.
create table if not exists content_segments (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null references content_items(id) on delete cascade,
  parent_segment_id uuid references content_segments(id) on delete cascade,
  segment_type text not null check (segment_type in ('section','heading','paragraph','sentence','transcript_segment','caption','footnote','other')),
  segment_key text,
  position integer not null,
  start_ms integer,
  end_ms integer,
  text text not null,
  text_sha256 text,
  source_locator jsonb not null default '{}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(content_item_id, segment_key),
  check(position > 0),
  check(start_ms is null or start_ms >= 0),
  check(end_ms is null or end_ms >= 0),
  check(start_ms is null or end_ms is null or end_ms >= start_ms)
);
create index if not exists idx_segments_item_position on content_segments(content_item_id, position);
create index if not exists idx_segments_parent on content_segments(parent_segment_id);
create index if not exists idx_segments_fts on content_segments using gin (to_tsvector('english', coalesce(text,'')));

-- Derived/AI/manual content never overwrites source-extracted fields.
create table if not exists content_enrichments (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null references content_items(id) on delete cascade,
  segment_id uuid references content_segments(id) on delete cascade,
  enrichment_type text not null,
  payload jsonb not null,
  provenance text not null check (provenance in ('derived','manual')),
  generator text,
  generator_version text,
  confidence numeric(5,4),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','auto_verified','human_verified','rejected')),
  created_at timestamptz not null default now(),
  check(confidence is null or confidence between 0 and 1)
);
create index if not exists idx_enrichments_item on content_enrichments(content_item_id, enrichment_type);

-- ============================================================
-- 3. READING HIERARCHY
-- Test -> Passage -> Paragraph. Questions use the universal assessment layer below.
-- ============================================================
create table if not exists reading_tests (
  id uuid primary key default gen_random_uuid(),
  collection_id uuid not null references content_collections(id) on delete cascade,
  external_test_no integer not null,
  title text,
  position integer not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(collection_id, external_test_no),
  check(external_test_no > 0 and position > 0)
);

create table if not exists reading_passages (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null unique references content_items(id) on delete cascade,
  test_id uuid references reading_tests(id) on delete set null,
  passage_no integer,
  instructions text,
  source_question_count integer,
  source_word_count integer,
  topic_code text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check(passage_no is null or passage_no > 0),
  check(source_question_count is null or source_question_count >= 0),
  check(source_word_count is null or source_word_count >= 0)
);
create index if not exists idx_reading_passages_test on reading_passages(test_id, passage_no);

create table if not exists reading_paragraphs (
  id uuid primary key default gen_random_uuid(),
  passage_id uuid not null references reading_passages(id) on delete cascade,
  segment_id uuid not null unique references content_segments(id) on delete cascade,
  paragraph_label text,
  position integer not null,
  is_footnote boolean not null default false,
  created_at timestamptz not null default now(),
  unique(passage_id, position),
  check(position > 0)
);

-- ============================================================
-- 4. UNIVERSAL ASSESSMENT LAYER
-- Reading, Listening and future test-like materials share one question model.
-- ============================================================
create table if not exists assessment_groups (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null references content_items(id) on delete cascade,
  position integer not null,
  type_code text not null,
  display_title text,
  instructions_text text not null default '',
  instructions_source_html text,
  -- Shared source stimulus for summary/table/diagram/other group-level prompts.
  -- Kept separate from instructions so the original question layout is not lost.
  stimulus_text text,
  stimulus_source_html text,
  stimulus_content jsonb not null default '{}'::jsonb,
  from_question_no integer,
  to_question_no integer,
  config jsonb not null default '{}'::jsonb,
  source_locator jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(content_item_id, position),
  check(position > 0),
  check(from_question_no is null or from_question_no > 0),
  check(to_question_no is null or from_question_no is null or to_question_no >= from_question_no)
);
create index if not exists idx_assessment_groups_item on assessment_groups(content_item_id, position);
create index if not exists idx_assessment_groups_type on assessment_groups(type_code);

create table if not exists assessment_questions (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null references content_items(id) on delete cascade,
  group_id uuid not null references assessment_groups(id) on delete cascade,
  question_no integer not null,
  source_key text,
  prompt_text text not null default '',
  prompt_source_html text,
  prompt_content jsonb not null default '{}'::jsonb,
  answer_constraint jsonb not null default '{}'::jsonb,
  source_locator jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(content_item_id, question_no),
  check(question_no > 0)
);
create index if not exists idx_assessment_questions_group on assessment_questions(group_id, question_no);

create table if not exists assessment_question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references assessment_questions(id) on delete cascade,
  option_key text not null,
  option_text text not null,
  position integer not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(question_id, option_key),
  unique(question_id, position),
  check(position > 0)
);

create table if not exists assessment_answers (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null unique references assessment_questions(id) on delete cascade,
  canonical_answer jsonb not null,
  answer_kind text not null check (answer_kind in ('text','choice','multi_choice','boolean_tristate','heading','matching','other')),
  provenance text not null default 'source' check (provenance in ('source','derived','manual')),
  source_locator jsonb not null default '{}'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists assessment_answer_variants (
  id uuid primary key default gen_random_uuid(),
  answer_id uuid not null references assessment_answers(id) on delete cascade,
  accepted_answer text not null,
  normalized_answer text not null,
  provenance text not null default 'source' check (provenance in ('source','derived','manual')),
  created_at timestamptz not null default now(),
  unique(answer_id, normalized_answer)
);

create table if not exists assessment_evidence (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references assessment_questions(id) on delete cascade,
  segment_id uuid references content_segments(id) on delete set null,
  evidence_type text not null check (evidence_type in ('support','contradiction','not_given_scope','source_marker','derived_explanation','missing_source_marker')),
  evidence_text text,
  start_char integer,
  end_char integer,
  start_ms integer,
  end_ms integer,
  marker_key text,
  explanation text,
  provenance text not null default 'source' check (provenance in ('source','derived','manual')),
  confidence numeric(5,4),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','auto_verified','human_verified','rejected')),
  source_locator jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check(start_char is null or start_char >= 0),
  check(end_char is null or end_char >= 0),
  check(start_char is null or end_char is null or end_char >= start_char),
  check(start_ms is null or start_ms >= 0),
  check(end_ms is null or end_ms >= 0),
  check(start_ms is null or end_ms is null or end_ms >= start_ms),
  check(confidence is null or confidence between 0 and 1)
);
create index if not exists idx_assessment_evidence_question on assessment_evidence(question_id);
create index if not exists idx_assessment_evidence_segment on assessment_evidence(segment_id);

-- ============================================================
-- 5. GLOBAL SENSE-AWARE LEXICON
-- One lexicon shared by Reading + Listening + TED/video + podcasts + lessons.
-- Lexeme is not equal to one meaning: one lexeme may have many senses.
-- ============================================================
create table if not exists lexemes (
  id uuid primary key default gen_random_uuid(),
  language text not null default 'en',
  lemma text not null,
  normalized_lemma text not null,
  part_of_speech text,
  lexical_type text not null check (lexical_type in ('word','phrasal_verb','collocation','idiom','fixed_expression','compound','term','other')),
  is_function_word boolean not null default false,
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists uq_lexeme_identity on lexemes(language, normalized_lemma, coalesce(part_of_speech,''), lexical_type);
create index if not exists idx_lexeme_normalized on lexemes(language, normalized_lemma);

create table if not exists lexical_forms (
  id uuid primary key default gen_random_uuid(),
  lexeme_id uuid not null references lexemes(id) on delete cascade,
  surface_form text not null,
  normalized_form text not null,
  form_type text not null default 'inflected',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(lexeme_id, normalized_form)
);
create index if not exists idx_lexical_forms_normalized on lexical_forms(normalized_form);

create table if not exists lexical_senses (
  id uuid primary key default gen_random_uuid(),
  lexeme_id uuid not null references lexemes(id) on delete cascade,
  sense_key text not null,
  definition_en text not null,
  translation_uz jsonb not null default '[]'::jsonb,
  register text,
  cefr text,
  domain_tags text[] not null default '{}',
  usage_notes text,
  dictionary_source text,
  external_sense_id text,
  provenance text not null default 'derived' check (provenance in ('source','derived','manual')),
  confidence numeric(5,4),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','auto_verified','human_verified','rejected')),
  metadata jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(lexeme_id, sense_key),
  unique(id, lexeme_id),
  check(confidence is null or confidence between 0 and 1)
);
create index if not exists idx_senses_lexeme on lexical_senses(lexeme_id);

create table if not exists lexical_relations (
  id uuid primary key default gen_random_uuid(),
  from_lexeme_id uuid not null references lexemes(id) on delete cascade,
  to_lexeme_id uuid not null references lexemes(id) on delete cascade,
  from_sense_id uuid,
  to_sense_id uuid,
  relation_type text not null check (relation_type in ('synonym','antonym','related','collocation_component','expression_component','derivation','other')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key(from_sense_id, from_lexeme_id) references lexical_senses(id, lexeme_id) on delete cascade,
  foreign key(to_sense_id, to_lexeme_id) references lexical_senses(id, lexeme_id) on delete cascade
);
create index if not exists idx_lexical_relations_from on lexical_relations(from_lexeme_id, relation_type);
create index if not exists idx_lexical_relations_to on lexical_relations(to_lexeme_id, relation_type);

-- Contextual filtering rules. Multi-word expressions are checked as a complete unit first.
-- We intentionally do NOT globally exclude lexical 'have'/'do' by lemma because they may carry content meaning.
create table if not exists vocabulary_exclusion_rules (
  id uuid primary key default gen_random_uuid(),
  language text not null default 'en',
  match_type text not null check (match_type in ('token','lemma','pos_class')),
  match_value text not null,
  reason text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(language, match_type, match_value)
);

insert into vocabulary_exclusion_rules(language, match_type, match_value, reason) values
('en','lemma','be','copular/auxiliary grammar word'),
('en','token','am','copular/auxiliary grammar word'),
('en','token','is','copular/auxiliary grammar word'),
('en','token','are','copular/auxiliary grammar word'),
('en','token','was','copular/auxiliary grammar word'),
('en','token','were','copular/auxiliary grammar word'),
('en','token','been','copular/auxiliary grammar word'),
('en','token','being','copular/auxiliary grammar word'),
('en','token','a','article'),('en','token','an','article'),('en','token','the','article'),
('en','token','this','demonstrative grammar word'),('en','token','that','demonstrative/relative grammar word'),
('en','token','these','demonstrative grammar word'),('en','token','those','demonstrative grammar word'),
('en','token','i','pronoun'),('en','token','you','pronoun'),('en','token','he','pronoun'),('en','token','she','pronoun'),
('en','token','it','pronoun'),('en','token','we','pronoun'),('en','token','they','pronoun'),('en','token','me','pronoun'),
('en','token','him','pronoun'),('en','token','her','pronoun'),('en','token','us','pronoun'),('en','token','them','pronoun'),
('en','token','and','basic conjunction'),('en','token','or','basic conjunction'),('en','token','but','basic conjunction'),
('en','token','of','basic preposition'),('en','token','to','basic preposition'),('en','token','in','basic preposition'),
('en','token','on','basic preposition'),('en','token','at','basic preposition'),('en','token','by','basic preposition'),
('en','token','for','basic preposition'),('en','token','from','basic preposition'),('en','token','with','basic preposition')
on conflict do nothing;

create table if not exists lexical_occurrences (
  id uuid primary key default gen_random_uuid(),
  content_item_id uuid not null references content_items(id) on delete cascade,
  segment_id uuid not null references content_segments(id) on delete cascade,
  lexeme_id uuid not null references lexemes(id) on delete cascade,
  sense_id uuid,
  surface_form text not null,
  normalized_surface text not null,
  start_char integer,
  end_char integer,
  start_ms integer,
  end_ms integer,
  sentence_text text,
  context_text text,
  occurrence_type text not null default 'token' check (occurrence_type in ('token','multiword_expression','term')),
  is_target_vocabulary boolean not null default true,
  selection_reason text,
  provenance text not null default 'derived' check (provenance in ('source','derived','manual')),
  extraction_method text,
  extractor_version text,
  confidence numeric(5,4),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','auto_verified','human_verified','rejected')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key(sense_id, lexeme_id) references lexical_senses(id, lexeme_id) on delete restrict,
  check(start_char is null or start_char >= 0),
  check(end_char is null or end_char >= 0),
  check(start_char is null or end_char is null or end_char >= start_char),
  check(start_ms is null or start_ms >= 0),
  check(end_ms is null or end_ms >= 0),
  check(start_ms is null or end_ms is null or end_ms >= start_ms),
  check(confidence is null or confidence between 0 and 1)
);
create index if not exists idx_occurrence_item on lexical_occurrences(content_item_id);
create index if not exists idx_occurrence_segment on lexical_occurrences(segment_id, start_char);
create index if not exists idx_occurrence_lexeme on lexical_occurrences(lexeme_id);
create index if not exists idx_occurrence_sense on lexical_occurrences(sense_id);

-- ============================================================
-- 6. STUDENT LEARNING / SRS: STRICTLY SEPARATE FROM CANONICAL LEXICON
-- ============================================================
create table if not exists student_lexeme_state (
  user_id uuid not null references auth.users(id) on delete cascade,
  lexeme_id uuid not null references lexemes(id) on delete cascade,
  status text not null default 'new' check (status in ('new','learning','review','learned','suspended')),
  first_seen_at timestamptz,
  last_seen_at timestamptz,
  next_review_at timestamptz,
  repetitions integer not null default 0,
  lapses integer not null default 0,
  interval_days numeric(10,2) not null default 0,
  ease_factor numeric(6,3) not null default 2.5,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key(user_id, lexeme_id)
);
create index if not exists idx_student_lexeme_due on student_lexeme_state(user_id, next_review_at);

create table if not exists student_sense_state (
  user_id uuid not null references auth.users(id) on delete cascade,
  sense_id uuid not null references lexical_senses(id) on delete cascade,
  status text not null default 'new' check (status in ('new','learning','review','learned','suspended')),
  first_seen_at timestamptz,
  last_seen_at timestamptz,
  next_review_at timestamptz,
  repetitions integer not null default 0,
  lapses integer not null default 0,
  interval_days numeric(10,2) not null default 0,
  ease_factor numeric(6,3) not null default 2.5,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key(user_id, sense_id)
);
create index if not exists idx_student_sense_due on student_sense_state(user_id, next_review_at);

create table if not exists student_review_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lexeme_id uuid references lexemes(id) on delete set null,
  sense_id uuid references lexical_senses(id) on delete set null,
  occurrence_id uuid references lexical_occurrences(id) on delete set null,
  activity_type text not null,
  grade smallint,
  response_ms integer,
  reviewed_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb,
  check(grade is null or grade between 0 and 5),
  check(response_ms is null or response_ms >= 0)
);
create index if not exists idx_review_events_user_time on student_review_events(user_id, reviewed_at desc);

alter table student_lexeme_state enable row level security;
alter table student_sense_state enable row level security;
alter table student_review_events enable row level security;

drop policy if exists "student owns lexeme state" on student_lexeme_state;
create policy "student owns lexeme state" on student_lexeme_state for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "student owns sense state" on student_sense_state;
create policy "student owns sense state" on student_sense_state for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "student owns review events" on student_review_events;
create policy "student owns review events" on student_review_events for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- INGESTION GATES (implemented in parser/validator, not by destructive triggers):
-- 1) source snapshots are checksum/version tracked and never silently overwritten;
-- 2) source text/questions/answers/evidence remain source provenance;
-- 3) derived translations/senses/explanations never overwrite source fields;
-- 4) question ranges cover questions without gaps/overlap;
-- 5) question count == answer count and matches manifest when provided;
-- 6) explicit evidence markers reproduce exact source text/timestamp ranges;
-- 7) missing source evidence is recorded, never fabricated as source;
-- 8) lexical occurrence -> canonical lexeme -> contextual sense;
-- 9) grammar/function words are excluded as standalone targets after contextual classification;
-- 10) multi-word expressions may contain function words and are evaluated as complete units;
-- 11) student state never changes canonical lexeme/sense records.
