-- Learners Area schema migration v1.0 -> v1.1
-- Adds group-level source stimulus required by IELTS summary/table/diagram style questions.

alter table assessment_groups
  add column if not exists stimulus_text text,
  add column if not exists stimulus_source_html text,
  add column if not exists stimulus_content jsonb not null default '{}'::jsonb;
