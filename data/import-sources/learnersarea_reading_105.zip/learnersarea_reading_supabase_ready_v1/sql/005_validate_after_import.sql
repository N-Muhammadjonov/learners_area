-- Run after import. Expected rows for Learners Area Reading v1 (01-105).
select 'reading_passages' as check_name, count(*)::bigint as actual, 105::bigint as expected from public.reading_passages
union all select 'assessment_questions', count(*), 1406 from public.assessment_questions
union all select 'assessment_answers', count(*), 1406 from public.assessment_answers
union all select 'assessment_evidence', count(*), 1406 from public.assessment_evidence
union all select 'lexemes', count(*), 2589 from public.lexemes
union all select 'lexical_senses', count(*), 2591 from public.lexical_senses
union all select 'lexical_occurrences', count(*), 3930 from public.lexical_occurrences;

-- Broken FK-style semantic links should be zero.
select count(*) as occurrences_without_lexeme
from public.lexical_occurrences o left join public.lexemes l on l.id=o.lexeme_id
where l.id is null;

select count(*) as occurrences_without_sense
from public.lexical_occurrences o
left join public.lexical_senses s on s.id=o.sense_id
where o.sense_id is not null and s.id is null;

-- Standalone function words should not be target vocabulary.
select count(*) as function_words_marked_target
from public.lexical_occurrences o
join public.lexemes l on l.id=o.lexeme_id
where o.is_target_vocabulary=true and l.is_function_word=true;
