# V5 current handoff — READY TO PASTE (overall PARTIAL)

Current authority: CHECKPOINT_V5.md, SOURCE_STATE_INVENTORY_V5.md, ROUTE_LEDGER_V5.md, COMPONENT_LEDGER_V5.md, route-ledger-v5.json, ADAPTER_CONTRACTS_V5.md, evidence/v5/phase1-source-audit.json and external deliverables/V5_VALIDATION.txt. Exact final code/delivery local=remote SHA is recorded externally and in delivery, not recursively inside its own commit. Baseline12308e89f67e573888ef4b23e6d85e005f2c2647.

## Paste into GPT Work

> Continue exact V5 PARTIAL migration on existing `arena/96836bcf-learners-area` ONLY, edits ONLY `migration/vanilla-frontend/`. Do not restart/redesign/use another framework/virtualDOM/hiddenReact/static placeholders. Inspect local/remote SHA/status first, preserve all legitimate newer work and immutable PARTIAL/V2/V3/V4/V5 archives. No reset/rebase/stash/clean/force-push/branch create/switch/merge/deploy or production/backend/app/src/public/content/services/drizzle/provider/DB/credentials/DNS/media changes. Explicit owner approval before production replacement.
>
> First INSPECT V5 runtime/build/converters/tests/source-state audit/ledgers/contracts and external independent ZIP validation. Verify sidecar/internal hashes/determinism. Phase1 ordinary frontend is CODE COMPLETE / FIXTURE VERIFIED, NOT VISUAL/LIVE/PRODUCTION accepted. Nine canonical closures: `/`, `/login`, `/register`, `/auth/recovery`, `/reset-password`, `/reset-password/confirm`, `/onboarding`, `/pending`, `/app/profile`. Desktop intro is a landing state, not `/intro`; Telegram confirmation is a provider state, not invented page. Overall9/108 canonical complete,19partial,80notstarted;6redirects+1retired separate =115records. Components51/206complete,10partial,145notstarted. Preserve V4 three recovery/reset and six component closures. Do not count closed shared controls as all staff callers or notification bell/read as full notification page completion. Broader BrandLogo API and unused standalone FocusToggle/TestFocusEntry remain unpromoted; module-body navigation composition (especially Vocabulary) remains partial.
>
> Verify211unit and202Chromium fixture baseline (27original+14V2+49V3+72V4+40V5), no failed/skipped; run `node scripts/regression-v5.mjs` to preserve historical evidence then `node tests/browser-v5.mjs`. Fresh extraction/npm ci --ignore-scripts/build/test and browser checks independently.25assets/sourceCSS/compiledCSS deterministic; candidate screenshots are NOT original-rendered comparison.0original comparisons,0live/production accepted, Safari/real mic/hardware absent. Runtime audit0, dev5high all-version braces/dependants; latest braces3.0.3 no safe patch, recommended Tailwind4.3.3 major CSS migration must not be blindly applied. Investigate parity-preserving toolchain mitigation in Phase10.
>
> Phase1 audit is evidence-backed native clients, not backend integration. Public/session/view APIs are proposals; static preview returns503, no fake identity/data/roles. Preserve own profile centred256PNG crop/multipart/ACK/error/retry/delete, ImageBitmap/FileReader cleanup and fallback CSP safety, strict server status enums, bounded opaque BC/storage hints, current-route header mutation-state pointer, unchanged-identity preference reread without shell destruction, locale sidebar/main scroll and focus/caret handoff, stable same-mode sidebar link nodes, main focus fallback, diagnostics server opt-in/redaction/frame-owner cleanup, confirm-select stale close fix. No credentials/protected data in storage. Support panel module metadata corrects source `app` fallback; do not invent dropdown notifications or `/api/notifications/read` endpoint: source bell is inbox link, read POST is `/api/notifications`.
>
> NEXT COMPLETE PHASE2 dashboard/reporting/existing mocks as a coherent module: audit every original source state/dependency/API action, finish actual native journeys/loading/empty/error/success/validation/keyboard/responsive/cleanup/contracts, test, repair ordinary defects, promote only proven CODE COMPLETE, then Phase3. Do not broaden indefinitely into partials or stop after foundation/docs/test-count growth. Required order thereafter: full ListeningTest1 nine activities/authored HTML/audio/transcripts/restrictions/exams/study/revision/autosave/timers/authoring; Reading; Writing; Speaking recording/playback/upload (Shadowing remains retired); Vocabulary/Grammar/Retention (genuine A–E ChooseTWO/Day8/server reveal, explicit grammar tabs); ALL Owner/Admin/Teacher actions/confirmations; remaining profile/courses/video/assignments/progress/liveclasses/notifications; final crossmodule/security/visual/performance/package. Original dynamic/deep/query/fragment/back/reload/redirect semantics, brand/assets/tokens/fonts/geometry/themes/locale/accessibility and authored-media boundaries must remain intact.
>
> Server retains identity/status/role/ownership/grading/revocation/media authority; opaque authored iframe allow-scripts ONLY, never allow-same-origin/CSP weakening/private-media/answers bundled. Specify narrow missing DTO/handler/input/output/redaction/errors/ownership contracts and complete native consumers anyway. Missing ordinary frontend engines are NOT integration blockers. No fake recording/grading/provider identity, SQL proxy or destructive production tests. Adapt/integrate only through approved original server services in nonproduction; do not ask for secrets in chat.
>
> Measure actual content/backend/media separately from pending frame under same warm/cache conditions. V5 finite30-switch trace has stable183listeners and590→561nodes, not general leak-freedom. Animation-frame timing is not certified pixel paint; no guaranteed1–100ms or invented Booster backend facts. Original-rendered baselines and live environment remain separate acceptance work.
>
> Publish deterministic CHECKPOINT archive while migration partial, CODE_COMPLETE filename only when entire requested frontend passes. Preserve historical archives. Independently extract/install/build/unit/browser/checksum/determinism, commit/push only existing branch and verify local=remote/main untouched. Final exact counts/SHAs/archiveSHA/security/remaining frontend/missing adapters/production changes and percentages with stable denominators or UNDETERMINED. If execution limits end work, save precise pushed resumable checkpoint, no fabricated external blockers or repeated permission-to-continue requests.

PRODUCTION CHANGES: NONE.

---

## Historical V4 handoff — retained, superseded above

# V4 current handoff — READY TO PASTE (overall PARTIAL)

Current authority: CHECKPOINT_V4.md, SOURCE_STATE_INVENTORY_V4.md, ROUTE_LEDGER_V4.md, COMPONENT_LEDGER_V4.md, route-ledger-v4.json, ADAPTER_CONTRACTS_V4.md, V4_VALIDATION_REPORT.md and external deliverables/V4_VALIDATION.txt. Previous checkpoint948d012cabe0c8c31fbc82502dc2077fc6af8293. Native code75f8e7652b6785355fee231f9a5c2f9db2f17ef7; packaging/test/docs follow-up commits are discoverable via git log. Final exact local/remote SHA is recorded in final delivery/external validation, not embedded recursively in its own commit.

## Paste into GPT Work

> Continue this exact V4 PARTIAL vanilla migration, do not restart or replace its foundation. Work ONLY on existing `arena/96836bcf-learners-area` and inside `migration/vanilla-frontend/`. Inspect `git status`, current local/remote branch and main SHA before editing. Preserve all newer legitimate work and immutable historical PARTIAL/V2/V3 ZIPs; no reset/rebase/stash/clean/force-push/create/switch branch/merge/deploy. Original app/src/public/content/services/drizzle/backend/configuration is read-only. No production/auth/provider/DB/DNS/storage/RIWI changes or credentials requested.
>
> First INSPECT the entire native runtime/build/generators/assets/tests, original source dependencies, V4 source-state inventory and every ledger/contract/security/performance/visual report. Verify V4 ZIP sidecar/internal hashes and external independent results; independently extract/npm ci/build/test/browser/assets/CSS as necessary. Before executing an historical browser harness in place, use scripts/regression-v4.mjs to snapshot/restore its evidence. It works without a historical ZIP in a standalone extraction. Fixtures are isolated transport contracts, never fake production APIs. Do not confuse passing probes, pending frames, imported routes or source-generated markup with complete modules.
>
> Current accounting:115records,108canonical candidates (active product denominator UNDETERMINED),3frontend-code-complete recovery/reset routes,24partial,81notstarted;6redirect-only codecomplete and1retired separate.206components:6codecomplete,46partial,154notstarted. Original-rendered/live/product accepted0. Code-complete scoped source components: LoginForm, ResetRequestForm, ResetConfirmForm, Breadcrumbs, ModuleContextHeading, GlobalSearch. Do not downgrade or expand these claims without evidence; no full Phase1 closure claimed. Validation181unit and162Chromium fixtures (27+14+49+72), zero source failures/skips; read independent result supplement for archive gates.
>
> Then REPAIR and FINISH the REST OF PHASE1 before any broad expansion: exhaustive original landing/login/register/Google/Telegram/onboarding/pending/logout/session/forcedlogout/multitab plus complete persistent responsive shell/theme/EN-UZ/focus/scroll/notifications/profile/utilities/diagnostics source-state/dependency audits and all native consumers. Drafts persist only for same-route preference refresh; real navigation wipes secrets; errors/pending preserve form nodes/caret; locale waits for mutation settlement/abort without replay. Public/session/view adapters remain proposals. Source Telegram statuses pending/confirmed/consumed/expired/cancelled; only confirmed exchanges, nonce bound, five-minute deadline, cancel during creation, no token storage. Landing CTA push versus intro replace/one-shot ended and mobile drawer breakpoint cleanup are already repaired. Search responsive popup is clamped from reproduced −57.5px offscreen defect without new design; keep source shortcut/loading/empty/hovers/keyboard/stale cleanup and parent headings.
>
> FINISH ONE COHERENT FUNCTIONAL MODULE BEFORE NEXT, in order: remaining Phase1; Dashboard/reporting/mocks/navigation/history/reload; full Listening with all nine Test1 activities, progressive hub-first authored HTML/media, transcript restrictions/timers/notes/flags/autosave/resume/review/authoring/import; full Reading; Writing; Speaking excluding retired Shadowing; Vocabulary/Grammar including genuine writing/speaking tabs; Retention/MCQ preserving A–E true ChooseTWO/Day8/server reveal; ALL Owner/Admin/Teacher actions with secure confirmations; all remaining pages/components. No redesign/static snapshots/alternate framework/hidden React or placeholder-as-success. Preserve existing source geometry/assets/tokens/fonts/EN-UZ/day-night/responsive/keyboard/transitions and dynamic/deep/query/fragment/back-forward/reload/redirect semantics. Opaque authored iframe only allow-scripts, never allow-same-origin or CSP weakening. Server remains authoritative for identity/status/role/ownership/media/grading/revocation; no fake data or generic SQL proxy.
>
> For EACH module, inventory source states/dependencies first; implement every ordinary frontend state/interaction/loading/empty/error/validation/cleanup; specify any missing adapter with exact original source/input/DTO/redaction/errors/role/ownership and complete native consumers anyway; run targeted unit and real DOM journeys across1440×900/768×1024/390×844×EN/UZ×day/night. Rerun intact181unit/162browser baseline and add meaningful adversarial/journey coverage. Source-template/CSS identity is not original-rendered comparison. Obtain legitimate rendered baseline/environment when available; mark otherwise unverified. Safari/hardware/live are separate. Do not run production destructive actions. Measure actual usable content separately from pending shell, backend and media under same cache conditions; no guaranteed1–100ms claim or invented Booster internals. Five high dev advisories still need a safe parity-preserving investigation; runtime0 does not mean vulnerability-free.
>
> Then ADAPT narrow DTOs through approved existing server services and INTEGRATE/VERIFY only in an owner-approved nonproduction environment. Explicit owner approval is required before any production replacement/deployment. Publish deterministic CHECKPOINT archive while partial, CODE_COMPLETE only after every ordinary module gate; independently extract/install/build/unit/browser/checksum/assets/CSS and compare two archive hashes. Commit/push ONLY this existing branch and verify remote SHA/main unchanged. Report exact route/component/test/visual/live counts, stable denominators or UNDETERMINED. If execution limits end work, save a precise pushed resumable checkpoint, not a fabricated external blocker or repeated request to continue.

PRODUCTION CHANGES: NONE.

---

## Historical V3 handoff — retained, superseded above

# V3 continuation — READY-TO-PASTE GPT Work handoff

**Status PARTIAL, not FRONTEND CODE COMPLETE.** Current authority: CHECKPOINT_V3.md, ROUTE_LEDGER_V3.md, route-ledger-v3.json, ADAPTER_CONTRACTS_V3.md and evidence/v3/. V2/history below are retained, not current completion claims. Source code checkpoint a4f72f8e558398e83d2ad268b1485d343eb0cb1e (after6259ff1); baseline/main9a7d9fc5a93608078644d61cd9f9850c05c4ddc8. Final package/delivery SHA and independent archive validation: final response / deliverables/V3_VALIDATION.txt / checksum sidecar.

## Paste this prompt into GPT Work

> Continue the existing Learners Area vanilla migration from its V3 PARTIAL checkpoint, not from scratch. Work only on the existing `arena/96836bcf-learners-area` branch and only under `migration/vanilla-frontend/`. Preserve all valid newer commits and immutable historical PARTIAL/V2/V3 delivery artifacts. Do not reset/rebase/clean/stash/force-push, create/switch branches, merge/deploy or touch original application/backend/services/content/configuration/production.
>
> First inspect current Git local/remote/main, README, CHECKPOINT_V3, both historical V2 and current V3 ledgers/contracts, GPT_WORK_HANDOFF, KNOWN_LIMITATIONS, functional/visual/security/performance reports and all native runtime/build/generator/test/assets. Verify package sidecar/internal checksums and read independent extraction/install/build/unit/browser logs alongside the V3 archive. Do not overwrite its evidence/manifest by running tests in place without a disposable extraction or backup/restore.
>
> Actual stable inventory:115 page records (107canonical candidates,1conditional,6redirect-only,1retired),27IN PROGRESS,81NOT STARTED,0accepted product pages;206component source files (50partial,156NOT STARTED,0accepted);214original API handlers;13supplemental boundaries. Source build and142unit +27original/14V2/49V3 Chromium probes passed. These are fixture/subset results, NOT live/visual/full-state acceptance. Original comparisons0, live accepted0; Safari/hardware mic/media unverified. Percentages UNDETERMINED.
>
> PRIORITY: finish ordinary source-derived states and coherent workflows of the EXISTING27 candidates before broad expansion. The V3 targeted audit is NOT exhaustive. For each source page inspect every imported component/layout/style/handler/state/API/keyboard/focus/media/cleanup path, build a source-state acceptance matrix, repair ordinary UI and add focused state/browser adversarial tests. Do not equate a touched module, source markup, pending frame or passing fixture with complete UI. Missing client engines/forms/tables are engineering work, not external blockers.
>
> Preserve native HTML/CSS/JS/DOM/History/Fetch/ESmodules only, no framework/virtual DOM/hooks shim; reviewed build-time pure-source extraction allowed. Preserve exact brand/assets/fonts/tokens/themes/locale/geometry/responsive behavior, redirects, query/deep/fragment/Back/Forward/reload semantics. Keep explicit Grammar writing/speaking tabs real; never revive Shadowing. Preserve source catalogue section navigation/headings and focus-only arrows/Home/End.
>
> Inspect the current fixes before changing architecture: shared recovery LoginForm, bootstrap/error/draft/form constraints; session invalidation after onboarding/admission and role/status scoped teardown; source confirmation/profile mouse-focus behavior; independent Dashboard/openLessons/mock regions; validated MCQ stages and true A–E ChooseTWO with no artificial cap and server reveal; notification serialization/observer and report lifecycle; source entry frames with hidden/inert outgoing private content; stale-import abort guards; code-only bounded prewarm (NO private DTO/attempt/retention/media prefetch); per-history-entry scroll. Native imports cannot be physically canceled; guards must prevent follow-up/commit.
>
> Complete ListeningTest1nine activities, authored host/timers/notes/flags/autosave/resume/outbox/private-media transitions and progressive hub-first/serverregistry behavior. Opaque iframe allow-scripts only, never allow-same-origin or weaker CSP. Complete Reading/Writing/Speaking/Vocabulary/Grammar/Retention and all Owner/Admin/Teacher actions with source confirmations, then profile/courses/video/notifications/support/etc, semantically classifying remaining81records. Do not add invented content/results/identities or simplified substitute products. The source itself does not enable a mock runner; do not invent one.
>
> Server remains authoritative for HttpOnly identity/status/role/permissions, ownership/revocation/grading/reveals/media. No browser token migration, local role authority, raw SQL/database proxy, service credentials, private content/answers/public-media substitution. Proposed `/api/frontend/public|session|view` are NOT existing backend endpoints. Inspect original source functions in contracts/registry/inventory, complete narrow nested DTO schemas/redaction and native loading/success/empty/error consumers. With EXPLICIT owner approval only, adapt/integrate with existing authoritative server functions/endpoints in an isolated review environment; verify CSRF, cookie rotation, cross-user denial, role downgrade, expiry/SSE/reconnect and media/reveal redaction. Missing backend cannot justify missing frontend work.
>
> Preserve all58V2unit and unchanged27original/14V2browser tests, and all later legitimate tests; extend rather than weaken. Re-run full suites and inspect result counts (filtered runs overwrite reports); keep historical evidence immutable. Test390×844/768×1024/1440×900 ×EN/UZ ×day/night for implemented workflows, direct/deep/reload/back-forward/repeated navigation, pointer and keyboard. Collect genuine original-vs-native visual comparisons and approved live role/media tests; Chromium≠Safari, fake media≠hardware mic acceptance. Never mark unrun gates as pass.
>
> Performance: pending-frame DOM1.0/0.8ms is NOT content readiness. Warm local30-row fixture medians were content DOM42.8/82.1ms and after-frame-opportunity456.7/478.3ms at0/50ms added fixture latency; no guaranteed perceived1–100ms or original comparison. Investigate rendering/frame scheduling on real devices and benchmark same-cache conditions with interaction/content/backend/media separated. Source diagnostic shows finite stable listener/doc counts, not leak freedom.5high dev-only audit findings remain; do safe dependency work, not a forced major Tailwind redesign. Selector-parser7.1.6 override had byte-identical CSS against6.1.4.
>
> Commit meaningful checkpoints on this exact branch, push only it and verify remote; preserve main and production. New package must be deterministic, checksummed and independently extracted/npmci/built/unit AND browser tested, including assets/standalone source inputs. Use a NEW CHECKPOINT name unless code-complete gates are truly met; never overwrite historical archives. Update ledgers/contracts/reports/handoff honestly, including stable denominators or UNDETERMINED for implementation/functional-security/visual-integration metrics. Explicit owner approval is required before production replacement; this prompt gives NO approval to touch backend/DB/Supabase/Railway/Cloudflare/Telegram/main/site or deploy.

## Owner/reviewer actions

1. Review V3 engineering checkpoint and remaining source-state gaps; it is not ready to replace production.
2. Confirm active canonical/product semantics and authoritative DTO projections without exposing credentials in chat.
3. Approve any separate backend integration/review environment and real roles/media testing explicitly; no destructive production testing.
4. Require actual code-complete, functional/security, original visual, live/media/device gates before a separately authorized replacement/deployment decision.

---

## Historical V2/foundation handoff — preserved, superseded above

# V2 continuation notice — current status PARTIAL

CONTINUE FROM V2, not from the historical two-page foundation described below. Read CHECKPOINT_V2.md, ROUTE_LEDGER_V2.md, route-ledger-v2.json, ADAPTER_CONTRACTS_V2.md and evidence/v2 first. Only use arena/96836bcf-learners-area. Previous checkpoint22560b7a17c9074e5ca18b1526537b239aa59716. Preserve newer commits, original22 tests and old PARTIAL ZIP. Start by inspecting/fixing implemented native code, then continue missing ordinary UI AND integrate/verify approved adapters. Never replace production without explicit owner approval; no deploy/merge/main/backend/DB/Railway/Cloudflare authorization.

Full V2 record: [CHECKPOINT_V2.md](CHECKPOINT_V2.md). Archive: `LEARNERS_AREA_VANILLA_FRONTEND_CHECKPOINT_V2.zip`. See final response/sidecar/validation for exact hashes and local/remote HEAD. A file cannot include its own commit hash.

Implementation%: UNDETERMINED (active denominator unconfirmed; 27 partial/115 page records). Functional/security%: UNDETERMINED (subset probes, not full acceptance). Visual/integration%: UNDETERMINED (0 baseline comparisons / 0 live accepted).

---

## Historical foundation record (22560b7) — retained for continuity, superseded above

# GPT Work handoff — PARTIAL MIGRATION CHECKPOINT

## 1. Identity, baseline and non-negotiable safety

Repository: private `https://github.com/N-Muhammadjonov/learners_area`.
Starting branch: `arena/96836bcf-learners-area`, assigned to this Arena session; not renamed.
Starting commit and last verified remote main/source-of-truth:
`9a7d9fc5a93608078644d61cd9f9850c05c4ddc8` (checked 2026-10-18 UTC).
Commit subject: “Stream private media after Listening hub paint and enforce session revocation (#41)”.
Migration directory: `migration/vanilla-frontend/`.
Delivery branch: `arena/96836bcf-learners-area`.
Branch URL: `https://github.com/N-Muhammadjonov/learners_area/tree/arena/96836bcf-learners-area/migration/vanilla-frontend`.
Use the final response and `git ls-remote` for the delivery commit (a file cannot include its own commit hash).

No original application/backend/content file was changed. No deploy, merge, production service call,
database mutation, content import, DNS/Railway/Cloudflare/Telegram configuration change was performed.
**Do not deploy this checkpoint.** The production app must stay untouched until all acceptance gates pass.

## 2. Actual status — no complete migration claim

115 page files, 206 component files, 214 API handler files and 13 layout/loading/error boundaries
were structurally discovered. The active-route semantic count is not established. Two page candidates
are implemented (`/`, `/auth/recovery`), plus not-found and route alias normalization. Zero pages
are fully visual+functional parity verified. 113 source page entries are unavailable, explicitly labeled.
Unimplemented interfaces are unfinished work, not fake external blockers or approved simplifications.

The full requested conversion exceeds this execution's implementation budget. This handoff preserves
actual tested code, not a proposal masquerading as completion. See KNOWN_LIMITATIONS.md.

## 3. Original architecture

Next.js 15 App Router, React 19, TypeScript/TSX, Tailwind 3.4.14 and global variable-driven CSS.
Server components obtain DB-backed user authority and data; API routes use the existing TypeScript
backend. Supabase PostgreSQL, Railway, private R2/Worker media and Telegram stay outside this task.
`src/app/app/layout.tsx` provides the DB authority gate for sibling shell/focus layouts.
`src/app/app/(shell)/layout.tsx` provides persistent independent sidebar/content scroll containers.
Listening focus pages host authored content with opaque sandbox isolation and authorized media controls.

## 4. Candidate architecture and key files

- `index.html`: root document, native module bootstrap, original-font preload, global CSS.
- `js/main.js`, `router.js`, `routes.js`: lazy native imports, safe same-origin History API,
  cancellation/stale-render protection, delegated links, explicit unavailable entries.
- `js/navigation.js`, `private-modules.js`: copied canonical aliases with query/fragment handling;
  retired Shadowing redirects to lessons, no Shadowing activity is added.
- `js/api-client.js`: native Fetch, same-origin cookies, no-store, JSON enforcement,
  bounded request timeout, concurrent GET dedup and per-subscriber cancellation. No retries/cache.
- `js/session.js`: presentation destination check only; not a capability grant or session lifecycle.
- `js/preferences.js`, `js/i18n/`: original Uzbek/English dictionaries, cookie-based choices.
- `js/components/`: safe DOM, original brand/SVG geometry, auth shell and preference controls.
- `modules/landing.js`: touch welcome, desktop intro with fallback; state resolved on activation.
- `modules/recovery.js`: real password-recovery administrative login form using existing endpoint.
- `modules/not-found.js`: original localized not-found structure.
- `modules/unavailable.js`: migration-status disclosure; never count as converted UI.
- `css/source.css`, `tailwind.source.mjs`: original stylesheet/config inputs.
- `css/global.css`, `fonts.css`, `fonts/`: compiled CSS and original licensed font files/roles.
- `scripts/build.mjs`: refresh safe source inputs in checkout or build independently from archive.
- `scripts/preview.mjs`: local build-only server, deep-link fallback, private APIs deliberately 503.
- `scripts/inventory.mjs`: AST structural scan; not a replacement for semantic/manual inspection.
- `scripts/package.py`: deterministic source ZIP, file manifest and SHA256SUMS verification.

The final browser runtime imports no React/Next/JSX or replacement framework. Build/test dependencies
are development-only. The backend is not embedded behind a wrapper.

## 5. Exact mapping and what the inventory does not prove

`ROUTE_MIGRATION_MATRIX.md` lists every discovered page pattern, parent layouts, imported component
closure, API literal candidates and current conversion state. `source-inventory.json` holds expanded
server dependencies, layouts, assets and API source checks. `COMPONENT_MIGRATION_MATRIX.md` covers
all component files; partial candidates do not count as exact conversions. `API_COMPATIBILITY_MATRIX.md`
lists every discovered handler and the small reviewed contract subset.

First finish semantic classification: Next config aliases precede pages; unconditional and conditional
redirects differ; role/layout gates and dynamic IDs affect reachability. Static literal extraction does
not capture every computed URL or response/body schema. Do not mark all 115 “active routes”.

## 6. APIs and missing adapters — existing vs proposed

Existing candidates use:
- GET `/api/auth/state`: `{ok,role,accountStatus,expiresAt}`, 401 for anonymous, private no-store.
- POST `/api/auth/recovery/login`: JSON email/password, server enforces ACTIVE owner/admin recovery.
- POST `/api/theme`: JSON theme, server cookie transport authority.
- POST `/api/locale`: JSON locale, server cookie transport authority.

These contracts were inspected; live integration was not exercised. The preview does not proxy them.

Missing **proposed**, not existing, API boundaries:
1. Public presentation bootstrap: server-selected locale/theme, brand defaults, auth release policy,
   public Telegram configured/mode/bot username and Google availability. Only public fields; never tokens.
   Normal login/register/reset must not infer release policy from local flags.
2. Authenticated shell DTO: DB-verified user identity/name/email/photo flag/onboarding, role/status/expiry.
   Existing `/api/auth/state` lacks identity, so cannot safely scope a full private cache or render shell.
3. Route-specific DTOs for direct service/DB reads in each page dependency closure. Define exact payloads
   only after inspecting the relevant page/service permissions and answer redaction. Never general SQL APIs.

Do not modify the existing backend in this Arena migration task. A subsequent GPT Work integration
must obtain/observe its separate backend authorization before implementing missing adapters. Prefer
existing endpoints whenever they already satisfy an exact contract. Preserve all request schemas,
server validation, CSRF/origin handling, ownership and failure semantics.

## 7. Authentication, session, roles and data isolation

No new auth provider or client role authority was introduced. Recovery uses native same-origin cookies.
Normal Telegram intent flow/widget/OIDC are NOT converted. Study `LoginForm.tsx`, `TelegramIntentLogin.tsx`,
`TelegramButton.tsx`, `public-auth-policy.ts`, and safe redirect handling before conversion.
Never ask the owner to paste passwords/cookies/secrets. Use authorized fixture environments.

Before enabling private views, convert `AccessChangeListener`, `PrivateResourceScope`, expiry timers,
SSE `/api/auth/changes` behavior, reconnect authority checks, logout, cross-tab invalidation and cache
clear/media teardown. Maintain DB-authoritative role/status/session revocation. Do not introduce eager
state polling on every click or localStorage privileges. Currently no settled private cache exists.

## 8. Media, Listening and exam security

Original latest Listening source is untouched. No protected content was statically bundled.
Do NOT treat this as a converted Listening module. Inspect current `authored-media-controller.ts`,
`private-resource.ts`, Listening hub/focus components, API redaction and authored runtime protocol.
Preserve Test 1's nine activities and latest tests from source, never rebuild content from guesses.
Hub must paint before audio preparation. Reuse authorized progressive streaming, revoke resources
on authority changes and keep original playback restrictions. Do not preload all media.
Authored iframes must remain opaque-origin sandboxed; never add allow-same-origin, weaken CSP or
postMessage source checks. Keep answers/server grading behind authenticated boundaries during exams.
R2/Worker production remains unchanged; no permanent private URLs or secrets in bundles/archives.

## 9. Verification and measured evidence

- `npm run build`: PASS.
- Foundation tests: 22 PASS, 0 FAIL, 0 SKIP, 0 BLOCKED.
- Chromium 133 smoke checks: 27 PASS, 0 FAIL, 0 SKIP, 0 BLOCKED.
- Source-vs-candidate visual comparisons: 0; baseline access BLOCKED.
- Live API group: BLOCKED; Safari and microphone groups SKIP.
- Screenshots: candidate-only, 390×844 / 768×1024 / 1440×900; both recovery themes.
- Performance: narrow local route benchmark in PERFORMANCE_REPORT.md; misses/proves no 1–100 ms goal.
  No original timing comparison or production performance claim.
- npm audit: 7 dev-only findings (5 high, 2 moderate), not a clean dependency audit.

See VISUAL_PARITY_REPORT.md, FUNCTIONAL_PARITY_REPORT.md and evidence/ for exact limits.
Two discovered preview defects were fixed: hidden desktop video-error fallback and dotfile SPA fallthrough.
Font binaries/roles were added after inspecting the Next/font configuration; no metric parity claim.

## 10. Exact safe commands

```sh
git status --short
git branch --show-current
git ls-remote origin refs/heads/main refs/heads/arena/96836bcf-learners-area
# Inspect/reconcile intervening main changes, without reset/rebase/stash/clean or overwriting work.
cd migration/vanilla-frontend
npm ci --ignore-scripts
npm run build
npm test
npm run preview
# second terminal, same directory:
node tests/browser.mjs
node scripts/performance.mjs
npm run package
python3 scripts/package.py --verify
```

Run inventory only in a source checkout. Archive independently builds from included source inputs.
Preview has no backend connection; do not point it at production to obtain a misleading “test”.
Use isolated approved fixtures with no real student records. Test one role/account scope at a time.

## 11. Remaining implementation order / acceptance gates

1. Verify latest legitimate main and preserve any intervening Listening/session/Reading/RIWI work.
2. Finish semantic route/component/API contracts, including query state, retired routes, errors and roles.
3. Obtain baseline screenshot/test access and separately authorized API adapters, if needed.
4. Convert exact shell/focus scrolling/nav/theme/locale/session lifecycle and auth flows first.
5. Convert all remaining educational and staff components from their actual state/effect contracts.
6. Reuse authored HTML securely behind existing runtime; migrate real media controls/autosave/grading.
7. Test all routes/deep links/roles/reloads/Back/Forward; include MCQ Choose TWO/A–E/Day 8,
   retention expiry/no-cache, Reading evidence, Writing typing/autosave and actual Speaking mic/upload.
8. Perform matching original/candidate screenshots and investigate every visible regression.
9. Compare matched-cache performance; measure visual/data/media readiness independently.
10. Rebuild archive, verify manifest/checksums/local-remote commit identity and all acceptance gates.
11. Only after explicit final integration authorization and acceptance may any deploy/merge be considered.

Current gates: runtime independence/source isolation/local build pass for the subset; complete active
inventory, full route/interaction/visual coverage and backend/session/media acceptance DO NOT pass.

## 12. Rollback considerations

There is no production migration to roll back. Ignore this directory/branch to keep the original app.
Do not delete original content or replace deployments. Later integration requires its own reviewed
rollback design retaining the original frontend and existing backend contracts until acceptance.

## Ready-to-paste GPT Work prompt

> Inspect private N-Muhammadjonov/learners_area branch arena/96836bcf-learners-area, directory
> migration/vanilla-frontend, beginning with README, GPT_WORK_HANDOFF, KNOWN_LIMITATIONS and all matrices.
> This is PARTIAL: 2 page candidates, 113 source page entries unconverted, 0 fully parity-verified routes.
> Do not call it complete, production-ready, or deploy it. Compare actual latest main against source
> 9a7d9fc5a93608078644d61cd9f9850c05c4ddc8 and reconcile legitimate intervening changes without resetting,
> rebasing, stashing, cleaning or overwriting work. Preserve accepted Listening hub-first streaming,
> all nine Test 1 activities, session revocation, Reading, MCQ semantics and RIWI workstreams.
> Complete semantic route/component/API contracts and convert every remaining active interface into
> actual HTML/CSS/native ES modules, with original visuals/states/interactions and all roles.
> Repair verified candidate defects; passing foundation tests is not application parity. Prefer existing
> API contracts; after separate backend authorization, implement the minimal missing public/auth shell
> and per-page server DTO adapters, preserving DB authority, ownership, answer redaction and media rules.
> No client role bypass, protected static content, allow-same-origin sandbox relaxation, secrets, fake
> data or simulated recordings. Test all modules with authorized isolated accounts/data, Chrome and
> Safari, both languages/themes, desktop/tablet/mobile, real media/mic where possible. Capture matching
> baseline screenshots and image diffs, measure matched-condition performance separately for UI/data/media,
> audit security/dependencies, verify package and Git delivery. Report every unverified gate honestly.
> Production backend/data/content/Railway/Cloudflare/Telegram and main remain untouched until explicit
> integration authorization and all acceptance gates pass. No deployment or merge by assumption.
