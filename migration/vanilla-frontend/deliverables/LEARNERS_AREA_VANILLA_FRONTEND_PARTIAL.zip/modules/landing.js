import {el,listen} from '../js/dom.js';
import {brandBlock} from '../js/components/brand.js';
import marks from '../js/components/marks.js';
import {entryDestination} from '../js/session.js';
import {dictionary,readPreferences} from '../js/preferences.js';
export async function mount({root,signal,navigate}){
 const dict=await dictionary(readPreferences().locale),t=dict.landing;
 const wrapper=el('div',{'data-root-entry':''}),touch=el('div',{'data-touch-welcome':''});
 const cta=el('button',{type:'button','data-landing-cta':'',class:'la-welcome-cta mt-10 inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-gold px-7 py-3 text-base font-semibold text-ink-950 transition-colors hover:bg-gold-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink-900'},t.cta,el('span',{'aria-hidden':'true'},'→'));
 const error=el('p',{role:'alert',class:'mt-4 text-sm text-band-bad'});
 async function proceed(){cta.disabled=true;try{const destination=await entryDestination(signal);if(!signal.aborted)await navigate(destination,{replace:true});}catch{if(!signal.aborted){error.textContent=dict.auth.errorNetwork;fallback();}}finally{cta.disabled=false;}}
 listen(cta,'click',proceed,signal);
 const orbit=el('div',{class:'la-welcome-orbit','aria-hidden':'true'});
 ['listening','reading','writing','speaking','grammar','vocabulary'].forEach((kind,index)=>{const holder=el('span',{class:'module-emoji','aria-hidden':'true'}); // Static trusted SVG geometry only; no response or user text enters this parser.
 const parser=new DOMParser();const doc=parser.parseFromString(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false">${marks[kind]}</svg>`,'image/svg+xml');holder.append(document.importNode(doc.documentElement,true));orbit.append(el('span',{class:`la-welcome-chip la-welcome-chip-${index}`},holder));});
 touch.append(el('div',{'data-theme':'night',class:'la-welcome flex min-h-dvh flex-col bg-paper text-ink-900',style:{paddingLeft:'env(safe-area-inset-left)',paddingRight:'env(safe-area-inset-right)'}},el('div',{class:'la-welcome-cosmos','aria-hidden':'true'},el('span',{class:'la-welcome-ring la-welcome-ring-one'}),el('span',{class:'la-welcome-ring la-welcome-ring-two'}),el('span',{class:'la-welcome-aurora'})),el('div',{class:'px-6 pt-6'},el('a',{href:'https://t.me/learners_area',target:'_blank',rel:'noopener noreferrer','aria-label':dict.shell.telegramBrand,'data-landing-brand-link':'',class:'inline-flex rounded-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2'},brandBlock())),el('main',{class:'la-welcome-main flex flex-1 flex-col items-center justify-center px-6 py-16 text-center'},orbit,el('h1',{class:'la-welcome-heading max-w-4xl font-display text-4xl font-bold leading-tight tracking-tight text-ink-900 sm:text-5xl md:text-6xl'},el('span',{class:'la-welcome-text block'},t.headlineLead),' ',el('span',{class:'la-welcome-text la-welcome-text-second mt-1 block'},t.headlineWith,' ',el('span',{class:'text-gold'},t.headlineAccent))),el('span',{'aria-hidden':'true',class:'mt-8 block h-px w-24 bg-gold/70 sm:w-32','data-landing-divider':''}),cta,error),el('footer',{class:'px-6 pb-8 text-center text-xs text-ink-300',style:{paddingBottom:'calc(2rem + env(safe-area-inset-bottom))'},'data-landing-footer':''},t.footer)));
 wrapper.append(touch);root.append(wrapper);
 const media=matchMedia('(min-width: 1024px) and (hover: hover) and (pointer: fine)');let video,timer,unavailable=false;
 function stop(){clearTimeout(timer);if(video){video.pause();video.removeAttribute('src');video.load();video=null;}}
 function fallback(){unavailable=true;stop();touch.style.display='block';wrapper.replaceChildren(touch);}
 function update(){stop();if(!media.matches||unavailable){wrapper.replaceChildren(touch);return;}video=el('video',{src:'/brand/Learners_Area_intro_optimized_v17.mp4',autoplay:true,muted:true,playsinline:true,preload:'auto','aria-hidden':'true',tabindex:'-1',class:'h-dvh w-full object-contain'});video.muted=true;listen(video,'ended',proceed,signal);listen(video,'error',fallback,signal);wrapper.replaceChildren(el('main',{class:'flex min-h-dvh items-center justify-center bg-black','data-desktop-intro':''},video));timer=setTimeout(fallback,20000);video.play()?.catch(fallback);}
 media.addEventListener('change',update,{signal});update();signal.addEventListener('abort',stop,{once:true});return stop;
}
