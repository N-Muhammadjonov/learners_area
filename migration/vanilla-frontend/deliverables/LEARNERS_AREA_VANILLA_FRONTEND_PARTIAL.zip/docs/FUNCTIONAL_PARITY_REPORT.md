# Functional parity — PARTIAL

## Candidate verification, not application acceptance

- Build command: PASS (1 executed check).
- Foundation unit/DOM suite: **22 PASS, 0 FAIL, 0 SKIP, 0 BLOCKED**.
- Chromium smoke checks: **27 PASS, 0 FAIL, 0 SKIP, 0 BLOCKED**.
- Live authenticated backend integration: **0 PASS, 0 FAIL, 0 SKIP, 1 BLOCKED verification group**.
- Original-vs-candidate visual comparison: **0 PASS, 0 FAIL, 0 SKIP, 1 BLOCKED group**.
- Safari compatibility: **0 PASS, 0 FAIL, 1 SKIP group, 0 BLOCKED**.
- Microphone/hardware: **0 PASS, 0 FAIL, 1 SKIP group, 0 BLOCKED**.

Skipped/blocked groups are not tests that ran. They are recorded acceptance activities, not counted
inside the 49 passing foundation/smoke assertions. Evidence: evidence/unit-results.tap and
browser-results.json. No hosted CI workflow was created, run or waived.

## Implemented candidate behavior

Router dynamic patterns, direct URL loading, static-server fallback, query/fragments, History API
Back/Forward, stale lazy-load rejection, event cleanup. Historical aliases and retired Shadowing
normalize to current destinations (target interfaces remain unconverted). Safe redirect function
is copied from current source. API JSON/error/no-store rules, GET dedup/cancellation, no mutation
retry. Dictionaries have matching key shapes. Original brand images and six SVG ornaments.
Recovery has required real email/password inputs, accessible labels, pending disabling and server
error display; no fake success. Theme persistence rollback and locale switch work against isolated
browser fixtures. Source inventory tests never equate unavailable routes with converted ones.

## Module status

| Module | Status | Evidence / remaining work |
|---|---|---|
| Entry `/` | PARTIAL candidate | Source-based welcome/desktop video host; original pixel comparison and server-pre-resolved destination missing |
| Recovery `/auth/recovery` | PARTIAL candidate | Real form + existing API adapter; live success/role eligibility unavailable; failure categories incomplete |
| Not-found | PARTIAL candidate | Original localized structure; unknown-route browser check; HTTP status integration missing |
| Dashboard | NOT CONVERTED | Explicit unavailable surface; source intact |
| Listening | NOT CONVERTED | All hubs, activities, streaming, exams/review/autosave remain original-only |
| Reading | NOT CONVERTED | Passages, evidence, timers, grading remain original-only |
| Writing | NOT CONVERTED | Editors, counting, autosave, exams/submissions remain original-only |
| Speaking | NOT CONVERTED | Real recorder/mic, playback, partner/AI interfaces not migrated |
| Vocabulary | NOT CONVERTED | Lookup/senses/folders/review/games not migrated |
| Grammar | NOT CONVERTED | Lessons/exercises/authoring not migrated |
| Retention | NOT CONVERTED | Timing/visibility/results/authoring not migrated |
| MCQ | NOT CONVERTED | Original questions/multi-select/Day 8/pagination untouched; no converted workflow |
| Owner | NOT CONVERTED | All tables, workflows, destructive confirmations remain to implement |
| Admin | NOT CONVERTED | All tables, forms, uploads remain to implement |
| Teacher | NOT CONVERTED | All interfaces remain to implement |
| Other modules | NOT CONVERTED | Reports/progress/notifications/assignments/support/profile/courses/video/live classes/management etc. listed in route matrix |

No original feature or educational file was removed. Preservation in the original source is NOT
claimed to be preservation in this candidate. The app-wide acceptance gate is not met.
