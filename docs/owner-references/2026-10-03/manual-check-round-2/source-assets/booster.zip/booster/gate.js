{\rtf1\ansi\ansicpg1252\cocoartf2907
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 /* ===== BOOSTER 8.0 \'97 PAID-COURSE GATE =====\
   Loaded first on every protected page. No approved session -> back to the\
   login page (login.html). The cached flag alone is not trusted: the worker\
   (/api/me) is asked on every load, and a refused answer clears the session.\
   The teacher always passes. Content stays hidden until the check succeeds. */\
(function () \{\
  var API = "https://booster8-api.siroj0100s.workers.dev";   // <- if your workers.dev subdomain differs, change this one line\
  var here = location.pathname.split("/").pop() || "index.html";\
  if (here === "index.html" || here === "login.html" || here === "login") return;\
\
  var st = document.createElement("style");\
  st.textContent = "html.b8-gating body\{visibility:hidden!important\}";\
  document.documentElement.appendChild(st);\
  document.documentElement.classList.add("b8-gating");\
\
  function bounce() \{\
    try \{ localStorage.removeItem("b8_token"); \} catch (e) \{\}\
    try \{ sessionStorage.removeItem("b8_session"); \} catch (e) \{\}\
    location.replace("login.html?next=" + encodeURIComponent(here + location.search + location.hash));\
  \}\
  function pass() \{ document.documentElement.classList.remove("b8-gating"); \}\
\
  var tok = "", sess = null;\
  try \{ tok = localStorage.getItem("b8_token") || ""; \} catch (e) \{\}\
  try \{ sess = JSON.parse(sessionStorage.getItem("b8_session") || "null"); \} catch (e) \{\}\
  if (!tok) \{ bounce(); return; \}\
  if (sess && sess.approved) pass();   // show fast; server can still pull it back\
\
  fetch(API + "/api/me", \{ headers: \{ Authorization: "Bearer " + tok \} \})\
    .then(function (r) \{ return r.ok ? r.json() : null; \})\
    .then(function (d) \{\
      if (!d || !d.user) \{ bounce(); return; \}\
      if (!d.approved && !d.isTeacher) \{ bounce(); return; \}\
      try \{\
        sessionStorage.setItem("b8_session", JSON.stringify(\{\
          approved: true, email: d.user.email, name: d.user.name,\
          role: d.isTeacher ? "teacher" : "student"\
        \}));\
      \} catch (e) \{\}\
      pass();\
    \})\
    .catch(function () \{\
      // Offline / worker hiccup: trust a cached approval for this visit so a\
      // real student is never locked out by a blip; strangers have no cache.\
      if (sess && sess.approved) pass(); else bounce();\
    \});\
\})();\
}