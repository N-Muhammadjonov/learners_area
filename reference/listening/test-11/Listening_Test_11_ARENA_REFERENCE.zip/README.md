# Listening Test 11 — Owner Source Reference

This is a read-only Arena reference derived from the owner-supplied `Listening Test 11.zip`.
It is NOT production runtime content and its HTML/JS must never be executed as the Learners Area app.

## Owner product placement
- Product: Academic Listening
- Learner catalogue: `/app/listening/academic`
- Title: `Listening Test 11`
- Opening the test must lead to the native Learners Area test hub, not to the source HTML runtime.
- Hub activities must be derived from what this source genuinely supports. Test 11 supports 9 source activities, but other tests may have roughly 1–3 fewer or more depending on their own authored material. Never force a fixed activity count.

## Source facts
- 4 Parts / 40 questions
- Q1–10 Completion
- Q11–14 Map / Plan
- Q15–25 MCQ
- Q26–30 Matching
- Q31–40 Completion
- Full transcript for every Part
- Script Completion: 6 purposeful gaps per Part, 24 total
- Vocabulary: 20 items
- Audio: MP3, 80 kbps, 44.1 kHz stereo, 1650.964898 seconds

## Source-declared activities
1. Full IELTS Test
2. Review & Revision
3. Script Completion
4. MCQ Mastery
5. Map / Plan Mastery
6. Matching Mastery
7. Completion Mastery
8. Vocabulary Builder
9. Retry Weak Areas

## Important
The original full owner ZIP contains the MP3 and source HTML. This reference bundle pins their hashes but intentionally does not embed the 16.5 MB audio. Use the canonical Content OS/import/private-asset path for production ingestion. Do not invent missing data and do not substitute this Test 11 package for the separately pinned Test 10 source contract in `docs/LISTENING-SOURCE-ZIP-CONTRACT.md`.
